package com.cg.rms.service;



import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.rms.beans.CandidateLogin;
import com.cg.rms.beans.CompanyUser;
import com.cg.rms.dao.LoginDAO;
import com.cg.rms.dao.LoginDAOImpl;
import com.cg.rms.exception.RecruitmentException;



public class ValidationService {
    
 
LoginDAO ldao =new LoginDAOImpl() ;
  
    public boolean validateUserName(String user)throws RecruitmentException {
        
         
        String namePattern="[A-Za-z]{5,30}";
        if(Pattern.matches(namePattern,user))
        {
        	System.out.println("hello");
            return true;
        }
        else
        {
            throw new RecruitmentException("User name must contain only Alphanumeric and betwenn 5 to 30  characters  " );
        }
        
    }
    
    public boolean validatePassword(String password)throws RecruitmentException {
        
        String namePattern="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
        if(Pattern.matches(namePattern,password))
        {
            return true;
        }
        else
        {
            throw new RecruitmentException("Password must contain \n ** At least 8 chars Contains \n ** "
                    + " at least one digit \n ** Contains at least one lower alpha char and one upper alpha char \n "
                    + "** Contains at least one char within a set of special chars (@#%$^ etc.) \n"
                    + " ** Does not contain space, tab, etc." );
        }
        
    }
    
    
    
   
   public boolean validateContact(String contact,String name1) throws RecruitmentException
    {
        String namePattern="[A-Z][ ,A-Za-z.-]{2,24}";
        if(Pattern.matches(namePattern,contact))
        {
            return true;
        }
        else
        {
            throw new RecruitmentException("Invalid "+name1);
        }
    }
   
    public boolean validateEmail(String email) throws RecruitmentException {
        // TODO Auto-generated method stub
        if(email.length()<=30)
        {
            String namePattern="^[a-zA-Z0-9_+&*-]+(?:\\."+
                    "[a-zA-Z0-9_+&*-]+)*@" +
                    "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                    "A-Z]{2,7}$";
            if(Pattern.matches(namePattern,email))
            {
                return true;
            }
            else
            {
                throw new RecruitmentException("Invalid Email ID");
            }
        }
        else
        {
            throw new RecruitmentException("Invalid Email ID... Length should be less than 30");
        }
        
    }
    
    public boolean validatePhone(String cPhone) throws RecruitmentException {
        // TODO Auto-generated method stub
        String namePattern="[6-9][0-9]{9}";
        if(Pattern.matches(namePattern,cPhone))
        {
            return true;
        }
        else
        {
            throw new RecruitmentException("Invalid Phone Number,Number should contain only digits and 10 numbers");
        }
    }
    
    public boolean validateMaritalStatus(String status,String name1) throws RecruitmentException
    {
        String namePattern="[-A-Za-z]{1,14}";
        if(Pattern.matches(namePattern,status))
        {
            return true;
        }
        else
        {
            throw new RecruitmentException("Invalid Marital Status");
        }
    }
    
    public boolean validateGender(String gender) throws RecruitmentException
    {
       
        if(gender.equalsIgnoreCase("Male")||gender.equalsIgnoreCase("Female")||
        		gender.equalsIgnoreCase("M")||gender.equalsIgnoreCase("F"))
        {
            return true;
        }
        else
        {
            throw new RecruitmentException("Invalid gender");
        }
    }
    
    public boolean validatePassport(String passport) throws RecruitmentException {
        // TODO Auto-generated method stub
        String namePattern="[a-zA-Z]{2}[0-9]{7}";
        if(Pattern.matches(namePattern,passport))
        {
            return true;
        }
        else
        {
            throw new RecruitmentException("Invalid passport no.");
        }
    }
    
    public boolean validatePassingYear(String passingYear) throws RecruitmentException {
        // TODO Auto-generated method stub
        String namePattern="[1|2][0-9]{3}";
        if(Pattern.matches(namePattern,passingYear))
        {
            LocalDate dt=LocalDate.now();
            int y=dt.getYear();
            if(Integer.parseInt(passingYear)<=y)
            return true;
            else
            {
                throw new RecruitmentException("Invalid passing year !!! As passing year should not be greater than current year");
            }

        }
        else
        {
            throw new RecruitmentException("Invalid passing year");
        }
    }
    //Percentage
    //@Override
    public boolean validatePercent(double percent) throws RecruitmentException {
        // TODO Auto-generated method stub
        
        if(percent<=100 && percent>0)
        {
            String namePattern="[1-9]{0,3}[.]*[0-9]{0,2}";
            String d=percent+"";
            if(Pattern.matches(namePattern,d))
            {
                return true;
            }
            else
            {
                throw new RecruitmentException("Invalid Percent");
            }
        }
        else
        {
            throw new RecruitmentException("Invalid percent Range !! Percent should be between 0 and 100");
        }
        
        
    }
    }