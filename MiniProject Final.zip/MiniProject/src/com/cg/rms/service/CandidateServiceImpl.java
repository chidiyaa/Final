package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.Candidate;
import com.cg.rms.beans.CandidatePersonal;
import com.cg.rms.beans.CandidateQualifications;
import com.cg.rms.beans.CandidateWorkHistory;
import com.cg.rms.beans.JobRequirements;
import com.cg.rms.dao.CandidateDAO;
import com.cg.rms.dao.CandidateDAOImpl;
import com.cg.rms.exception.RecruitmentException;

public class CandidateServiceImpl implements CandidateService {
	
	CandidateDAO cdao=new CandidateDAOImpl();
	
	// Search for jobs based on qualification, position, years of experience,location
	@Override
	public ArrayList<JobRequirements> search(String qualification,
			String position, int experience,String location) throws RecruitmentException {
		
            ArrayList<JobRequirements> jobReq=cdao.getJobRequirements();
            ArrayList<JobRequirements> jobReq1=new ArrayList<JobRequirements>();
            for(JobRequirements job:jobReq)
            {
            	String qual=job.getQualificationRequired();
                Integer exp=job.getExperienceRequired();
                String loc=job.getJobLocation();
                String pos=job.getPositionRequired();
                if(pos.equalsIgnoreCase(position) && loc.equalsIgnoreCase(location) && exp==experience && qual.contains(qualification)){
                    jobReq1.add(job);
                    
                }
                
            }
            return jobReq1;
            
       
	}
	
	// Add Resume
	@Override
	public int addResume(Candidate candidate) throws RecruitmentException {
		// TODO Auto-generated method stub
		ArrayList<CandidatePersonal> cList=cdao.viewResume();
		for(CandidatePersonal cp:cList)
		{
			if(cp.getCandidateId().equals(candidate.getCandidatePersonal().getCandidateId()))
					{
				
						return -1;
					}
		}
		
		return cdao.addResume(candidate);
	}
	
	//Modify Resume
	@Override
	public int modifyResume(Candidate candidate,String candidateId) throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.modifyResume(candidate,candidateId);
	}
	
	//Apply for job
	@Override
	public int applyForJob(String jobId, String candidateId)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.applyForJob(jobId,candidateId);
	}
	
	//View Resume of candidate qualification details
	@Override
	public ArrayList<CandidateQualifications> viewResume1()
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.viewResume1();
	}
	////View Resume of candidate Personal details
	@Override
	public ArrayList<CandidatePersonal> viewResume()
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.viewResume();
	}
	//View Resume of candidate work history details
	@Override
	public ArrayList<CandidateWorkHistory> viewResume2()
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.viewResume2();
	}
	
	//Candidate to get job requirements of the company
	@Override
	public ArrayList<JobRequirements> getJobRequirements()
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.getJobRequirements();
	}
	

}
