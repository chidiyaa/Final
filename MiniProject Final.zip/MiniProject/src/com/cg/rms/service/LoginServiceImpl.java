package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.User;
import com.cg.rms.dao.LoginDAO;
import com.cg.rms.dao.LoginDAOImpl;
import com.cg.rms.exception.RecruitmentException;

public class LoginServiceImpl implements LoginService {

	LoginDAO loginDao=new LoginDAOImpl();
	
	//Validate login
	@Override
	public User login(String userName, String password)
			throws RecruitmentException {
		User user=loginDao.login(userName, password);
		if(user==null)
		{
			return null;
		}
		if(user.getUserName().equals(userName) && user.getPassword().equals(password))
		{
			return user;
		}
		else{
			return null;
			}
		
	}
	
	//Signup for new users 
	@Override
	public String signUp(User user) throws RecruitmentException {
		String userId=loginDao.signUp(user);
			return userId;
	}

	@Override
	public int validateCandidates(String userName) throws RecruitmentException {


		ArrayList<User> userList= loginDao.listAllUsers();
		for(User user:userList)
		{
			if(user.getUserName().equals(userName))
			{
				return 1;
			}
		}
		
		return 0;
		
	}

}
