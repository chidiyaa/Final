package com.cg.rms.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.PlacedCandidateService;
import com.cg.rms.service.PlacedCandidateServiceImpl;
//import com.cg.rms.service.ValidationService;
public class AdminUIImpl implements AdminUI{
    static PlacedCandidateService pcService=new PlacedCandidateServiceImpl();
    LoginUI login=new LoginUIImpl();
    @Override
    public void countpcposition(String designation) {
        ArrayList<String> placedCandidatenames=new ArrayList<String>();
        int i=0;
        try {
        	placedCandidatenames=pcService.pCountDesignation(designation);
        	if(placedCandidatenames.size()!=0)
        	{
        		
   
        	System.out.println("Total Candidates Placed as designation are");
        	System.out.println("Serial No.  Names");
        	System.out.println("=================\n");
        	}
           for(String names:placedCandidatenames)
           {
        	   i++;
        	   System.out.println(i+")         "+names);
        	   
           }
           System.out.println();
           System.out.println(i+" Number of candidate are Placed as "+ designation);
           System.out.println("---------------------------------------------");
        } catch (RecruitmentException e) {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
        }
        
        
    }
    @Override
    public void countpccompany(String company) {
        Scanner sc=new Scanner(System.in);
        ArrayList<String> placedCandidatenames=new ArrayList<String>();
        int i=0;
        try {
        	placedCandidatenames=pcService.pCountCompany(company);
        	if(placedCandidatenames.size()!=0)
        	{
        	System.out.println("Total Candidates Placed in Month are:\n");
        	System.out.println("Serial No.  Names");
        	System.out.println("=================\n");
        	}
        	for(String names:placedCandidatenames)
            {
         	   i++;
         	  System.out.println(i+")         "+names);
            }
        	System.out.println();
        	 System.out.println(i+" Number of candidate are Placed in "+ company);
        	 System.out.println("---------------------------------------------");
        } catch (RecruitmentException e) {
            // TODO Auto-generated catch block
        	System.out.println(e.getMessage());
        }
        
    }
    @Override
    public void countpcmonth(String month) {
        ArrayList<String> placedCandidatenames=new ArrayList<String>();
       int i=0;
        try {
        	placedCandidatenames=pcService.pCountMonth(month);
        	if(placedCandidatenames.size()!=0)
        	{
        	System.out.println("Total Candidates Placed in Month are:\n");
        	System.out.println("Serial No.  Names");
        	System.out.println("=================\n");
        	}
        	for(String names:placedCandidatenames)
           {
        	   i++;
        	   System.out.println(i+")         "+names);
           }
        	System.out.println();
        	 System.out.println(i+" Number of candidate are Placed in "+ month);
        	 System.out.println("---------------------------------------------");
        } catch (RecruitmentException e) {
            // TODO Auto-generated catch block
        	System.out.println(e.getMessage());
        }
        
    }
    @Override
    public void showAdminMenu(String id) throws RecruitmentException
    {
    	System.out.println("=============================");
    	System.out.println("         Admin Menu");
    	System.out.println("=============================");
    	System.out.println("1.Count of individuals  placed in a particular month\n"
        		+"2.Count of individuals  placed in a particular company\n"
        		+"3.Count of individuals placed in a particular position(designation)\n"
        		+"4.Logout"); 
    	Scanner sc=new Scanner(System.in);
    	int choice=0;
    	choice=sc.nextInt();
    	PlacedCandidateServiceImpl placedcandidateService=new PlacedCandidateServiceImpl();
		switch(choice)
		{
		case 1: System.out.println("Enter month");
		String month =sc.next();
		countpcmonth(month);break;
		case 2: System.out.println("Enter company");
		String company =sc.next();
		countpccompany(company);break;
		case 3:System.out.println("Enter designation");
		String designation =sc.next();
		countpcposition(designation);break;
		case 4:System.out.println("You have Successfully signed out");login.showMenu(); break;
		default:System.out.println("Invalid input");
		}
		showAdminMenu(id);
    	}
    
    }
