package com.cg.rms.client;



import com.cg.rms.ui.LoginUI;
import com.cg.rms.ui.LoginUIImpl;

//Main class for running the Recruitment management system application
public class Client {

		public static void main(String args[]) {
			LoginUI client=new LoginUIImpl();
			client.showMenu();
		}	

}
